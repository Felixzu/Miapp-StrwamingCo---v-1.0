package com.softidea.StreamingCo

// PlataformaItem.kt
data class PlataformaItem(
    val nombre: String,
    val iconoResId: Int
)

